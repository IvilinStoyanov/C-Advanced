﻿using P06_TrafficLights.Core;
using System;

namespace P06_TrafficLights
{
   public class Program
    {
        static void Main(string[] args)
        {
            new Engine().Run();
        }
    }
}
