﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06_TrafficLights.Models
{
    public enum LightColor
    {
        Red,
        Green,
        Yellow
    }
}
