﻿namespace P03_BarraksWars.Core.Commands
{
    public interface IExecutable
    {
    }
}