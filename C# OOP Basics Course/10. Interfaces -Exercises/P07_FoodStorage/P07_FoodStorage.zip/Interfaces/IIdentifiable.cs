﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_FoodStorage.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}