﻿using System;

namespace P07_FoodStorage
{
    using Controller;

    public class Program
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}